python manage.py shell < input.txt
